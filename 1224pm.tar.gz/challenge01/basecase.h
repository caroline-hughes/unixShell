#ifndef BASECASE_H
#define BASECASE_H

//int base_case(const char* cmd, const char** args);
int base_case(const char* cmd, char *const args[]);

#endif
