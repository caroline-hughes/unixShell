true&& 	echo dont 	need spaces
